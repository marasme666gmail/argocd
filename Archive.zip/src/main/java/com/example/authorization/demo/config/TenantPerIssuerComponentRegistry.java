package com.example.authorization.demo.config;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.lang.Nullable;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.security.oauth2.server.authorization.context.AuthorizationServerContext;
import org.springframework.security.oauth2.server.authorization.context.AuthorizationServerContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class TenantPerIssuerComponentRegistry {
	private final ConcurrentMap<String, Map<Class<?>, Object>> registry = new ConcurrentHashMap<>();

	public <T> void register(String tenantId, Class<T> componentClass, T component) {
		Assert.hasText(tenantId, "tenantId cannot be empty");
		Assert.notNull(componentClass, "componentClass cannot be null");
		Assert.notNull(component, "component cannot be null");
		Map<Class<?>, Object> components = this.registry.computeIfAbsent(tenantId, (key) -> new ConcurrentHashMap<>());
		components.put(componentClass, component);
	}

	// add to tenant registered client repository new client
	public void registerClient(String tenantId, RegisteredClient registeredClient) {
		Assert.hasText(tenantId, "tenantId cannot be empty");
		Assert.notNull(registeredClient, "registeredClient cannot be null");

		// Validate tenant exists in registry
		Map<Class<?>, Object> tenantComponents = registry.get(tenantId);
		if (tenantComponents == null) {
			throw new IllegalArgumentException("Tenant '" + tenantId + "' not found in registry. Available tenants: " + registry.keySet());
		}

		// Validate RegisteredClientRepository exists for tenant
		Object repositoryObject = tenantComponents.get(RegisteredClientRepository.class);
		if (repositoryObject == null) {
			throw new IllegalArgumentException("No RegisteredClientRepository found for tenant '" + tenantId + "'. Available components: " + tenantComponents.keySet());
		}

		// Validate client_id is unique within tenant
		RegisteredClientRepository repository = (RegisteredClientRepository) repositoryObject;
		if (repository.findByClientId(registeredClient.getClientId()) != null) {
			throw new IllegalArgumentException("Client with ID '" + registeredClient.getClientId() + "' already exists in tenant '" + tenantId + "'");
		}

		try {
			repository.save(registeredClient);
			System.out.println("✓ Successfully registered client '" + registeredClient.getClientId() + "' for tenant '" + tenantId + "'");
		} catch (Exception e) {
			throw new RuntimeException("Failed to save registered client '" + registeredClient.getClientId() + "' for tenant '" + tenantId + "'", e);
		}
	}

	@Nullable
	public <T> T get(String tenantId, Class<T> componentClass) {
		Assert.hasText(tenantId, "tenantId cannot be empty");
		Assert.notNull(componentClass, "componentClass cannot be null");
		Map<Class<?>, Object> components = this.registry.get(tenantId);
		if (components == null) {
			return null;
		}
		return componentClass.cast(components.get(componentClass));
	}

	@Nullable
	public <T> T get(Class<T> componentClass) {
		AuthorizationServerContext context = AuthorizationServerContextHolder.getContext();
		if (context == null || context.getIssuer() == null) {
			return null;
		}
		for (Map.Entry<String, Map<Class<?>, Object>> entry : this.registry.entrySet()) {
			if (context.getIssuer().endsWith(entry.getKey())) {
				return componentClass.cast(entry.getValue().get(componentClass));
			}
		}
		return null;
	}
}