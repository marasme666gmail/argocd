package com.example.authorization.demo;

import com.example.authorization.demo.config.TenantService;
import com.example.authorization.demo.config.TenantPerIssuerComponentRegistry;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.security.oauth2.core.oidc.OidcScopes;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.settings.ClientSettings;
import java.util.UUID;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    public ApplicationRunner tenantInitializer(TenantService tenantService,
                                             TenantPerIssuerComponentRegistry componentRegistry) {
        return args -> {
            try {
                System.out.println("=== Starting Tenant Initialization ===");



                // Create tenant_2
                tenantService.createTenant("tenant_2");
                System.out.println("✓ Created tenant_2");

                                // Create tenant_1
                tenantService.createTenant("tenant_1");
                System.out.println("✓ Created tenant_1");

                System.out.println("=== Adding Clients to Tenants ===");

            RegisteredClient client2 = RegisteredClient.withId(UUID.randomUUID().toString())
            .clientId("tenant_2_client")  // Different client_id from tenant_id
            .clientAuthenticationMethod(ClientAuthenticationMethod.NONE) 
            .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
            .authorizationGrantType(AuthorizationGrantType.REFRESH_TOKEN)
            .redirectUri("https://oidcdebugger.com/debug")
            .scope(OidcScopes.OPENID)
            .scope(OidcScopes.PROFILE)
            .scope("read")
            .scope("write")
            .clientSettings(ClientSettings.builder().requireProofKey(true).build()) // enable PKCE
            .build();
            componentRegistry.registerClient("tenant_2", client2);

    RegisteredClient client1 = RegisteredClient.withId(UUID.randomUUID().toString())
            .clientId("tenant_1_client")  // Different client_id from tenant_id
            .clientSecret("{noop}secret1")
            .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_POST) // Try POST instead of BASIC
            .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
            .authorizationGrantType(AuthorizationGrantType.REFRESH_TOKEN)
            .redirectUri("https://oidcdebugger.com/debug")
            .scope(OidcScopes.OPENID)
            .scope(OidcScopes.PROFILE)
            .scope("read")
            .scope("write")
            .clientSettings(ClientSettings.builder().requireAuthorizationConsent(true).build())
            .build();
            componentRegistry.registerClient("tenant_1", client1);



                System.out.println("=== Tenant and Client Initialization Completed ===");

            } catch (Exception e) {
                System.err.println("Failed to initialize tenants: " + e.getMessage());
                e.printStackTrace();
            }
        };
    }
}

