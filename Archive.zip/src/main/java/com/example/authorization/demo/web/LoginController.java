package com.example.authorization.demo.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

	@GetMapping("/tenant_1/login")
	public String loginTenant1(Model model) {
		model.addAttribute("tenantName", "Tenant 1");
		model.addAttribute("tenantId", "tenant_1");
		return "tenant_1_login";
	}

	@GetMapping("/tenant_2/login")
	public String loginTenant2(Model model) {
		model.addAttribute("tenantName", "Tenant 2");
		model.addAttribute("tenantId", "tenant_2");
		return "tenant_2_login";
	}

}
