package com.example.authorization.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;

@Configuration(proxyBeanMethods = false)
public class UserDetailsServiceConfig {

    @Bean
    public UserDetailsService userDetailsService(TenantPerIssuerComponentRegistry componentRegistry) {
        return new DelegatingUserDetailsService(componentRegistry);
    }

    private static class DelegatingUserDetailsService implements UserDetailsService {

        private final TenantPerIssuerComponentRegistry componentRegistry;

        private DelegatingUserDetailsService(TenantPerIssuerComponentRegistry componentRegistry) {
            this.componentRegistry = componentRegistry;
        }

        @Override
        public UserDetails loadUserByUsername(String username) {
            UserDetailsService userDetailsService = getUserDetailsService();
            return userDetailsService.loadUserByUsername(username);
        }

        private UserDetailsService getUserDetailsService() {

            String tenantId = getCurrentTenantId();
            if (tenantId == null || tenantId.isEmpty()) {
                throw new IllegalStateException("No tenant ID found");
            }
            UserDetailsService userDetailsService =
                    this.componentRegistry.get(tenantId, UserDetailsService.class);
            if (userDetailsService == null) {
                throw new IllegalStateException("UserDetailsService not found for \"requested\" tenant identifier.");
            }
            return userDetailsService;
        }

    private String getCurrentTenantId() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attributes == null) {
            throw new IllegalStateException("No current request found");
        }
        HttpServletRequest request = attributes.getRequest();
        if (request == null) {
            throw new IllegalStateException("No current request found");
        }

        String uri = request.getRequestURI();
        if (uri.matches("^/([a-z0-9_]+)/.*")) {
            return uri.split("/")[1];
        }

        // Default tenant if none found
        return "default";
    }
    }
}
