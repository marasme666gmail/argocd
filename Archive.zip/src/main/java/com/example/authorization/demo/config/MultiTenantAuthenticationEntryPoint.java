package com.example.authorization.demo.config;

import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import org.springframework.security.core.AuthenticationException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class MultiTenantAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request,
                         HttpServletResponse response,
                         AuthenticationException authException) throws IOException {
        // Custom logic to handle authentication entry point for multi-tenant applications
        // For example, you can redirect to a tenant-specific login page or return an error response
        String tenantId = extractTenantFromRequest(request);
        response.sendRedirect("/" + tenantId + "/login");
    }

    private String extractTenantFromRequest(HttpServletRequest request) {
        // Strategy 1: URL path parameter (/tenant_1/login)
        String uri = request.getRequestURI();
        if (uri.matches("^/([a-z0-9_]+)/.*")) {
            return uri.split("/")[1];
        }
                
        // Default tenant if none found
        return "default";
    }    

}
