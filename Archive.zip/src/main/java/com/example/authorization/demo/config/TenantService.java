package com.example.authorization.demo.config;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.sql.Connection;
import java.sql.Statement;
import java.util.UUID;

import javax.sql.DataSource;

import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.oauth2.server.authorization.JdbcOAuth2AuthorizationConsentService;
import org.springframework.security.oauth2.server.authorization.JdbcOAuth2AuthorizationService;
import org.springframework.security.oauth2.server.authorization.OAuth2AuthorizationConsentService;
import org.springframework.security.oauth2.server.authorization.OAuth2AuthorizationService;
import org.springframework.security.oauth2.server.authorization.client.JdbcRegisteredClientRepository;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TenantService {

    private final TenantPerIssuerComponentRegistry componentRegistry;
    private final DataSource dataSource;

    public TenantService(TenantPerIssuerComponentRegistry componentRegistry, DataSource dataSource) {
        this.componentRegistry = componentRegistry;
        this.dataSource = dataSource;
    }

    @Transactional
    public void createTenant(String tenantId) {
        
        // Create tenant-specific JDBC template
        JdbcTemplate jdbcOperations = createTenantJdbcTemplate(tenantId);

 
        UserDetailsService userDetailsService =
                new JdbcUserDetailsManager(new TenantAwareDataSource(dataSource, tenantId));

        this.componentRegistry.register(tenantId, UserDetailsService.class, userDetailsService);

        RegisteredClientRepository registeredClientRepository =
                new JdbcRegisteredClientRepository(jdbcOperations);
        this.componentRegistry.register(tenantId, RegisteredClientRepository.class, registeredClientRepository);

        OAuth2AuthorizationService authorizationService =
                new JdbcOAuth2AuthorizationService(jdbcOperations, registeredClientRepository);
        this.componentRegistry.register(tenantId, OAuth2AuthorizationService.class, authorizationService);

        OAuth2AuthorizationConsentService authorizationConsentService =
                new JdbcOAuth2AuthorizationConsentService(jdbcOperations, registeredClientRepository);
        this.componentRegistry.register(tenantId, OAuth2AuthorizationConsentService.class, authorizationConsentService);

        JWKSet jwkSet = new JWKSet(generateRSAJwk());
        this.componentRegistry.register(tenantId, JWKSet.class, jwkSet);
        
        System.out.println("✓ Created tenant: " + tenantId);
    }

    private JdbcTemplate createTenantJdbcTemplate(String tenantId) {
        return new JdbcTemplate(new TenantAwareDataSource(dataSource, tenantId));
    }

    // Tenant-aware DataSource wrapper
    private static class TenantAwareDataSource implements DataSource {
        private final DataSource delegate;
        private final String tenantId;

        public TenantAwareDataSource(DataSource delegate, String tenantId) {
            this.delegate = delegate;
            this.tenantId = tenantId;
        }

        @Override
        public Connection getConnection() throws java.sql.SQLException {
            Connection connection = delegate.getConnection();
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("SET search_path TO " + tenantId + "");
            }
            return connection;
        }

        @Override
        public Connection getConnection(String username, String password) throws java.sql.SQLException {
            Connection connection = delegate.getConnection(username, password);
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("SET search_path TO " + tenantId + "");
            }
            return connection;
        }

        // Delegate all other methods to the original DataSource
        @Override
        public java.io.PrintWriter getLogWriter() throws java.sql.SQLException {
            return delegate.getLogWriter();
        }

        @Override
        public void setLogWriter(java.io.PrintWriter out) throws java.sql.SQLException {
            delegate.setLogWriter(out);
        }

        @Override
        public void setLoginTimeout(int seconds) throws java.sql.SQLException {
            delegate.setLoginTimeout(seconds);
        }

        @Override
        public int getLoginTimeout() throws java.sql.SQLException {
            return delegate.getLoginTimeout();
        }

        @Override
        public java.util.logging.Logger getParentLogger() throws java.sql.SQLFeatureNotSupportedException {
            return delegate.getParentLogger();
        }

        @Override
        public <T> T unwrap(Class<T> iface) throws java.sql.SQLException {
            return delegate.unwrap(iface);
        }

        @Override
        public boolean isWrapperFor(Class<?> iface) throws java.sql.SQLException {
            return delegate.isWrapperFor(iface);
        }
    }

    private static RSAKey generateRSAJwk() {
        KeyPair keyPair;
        try {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(2048);
            keyPair = keyPairGenerator.generateKeyPair();
        } catch (Exception ex) {
            throw new IllegalStateException(ex);
        }

        RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
        RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
        return new RSAKey.Builder(publicKey)
                .privateKey(privateKey)
                .keyID(UUID.randomUUID().toString())
                .build();
    }
}