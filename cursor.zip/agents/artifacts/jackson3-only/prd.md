# PRD: Jackson 3 Only Standard

| Field | Value |
|-------|-------|
| Feature ID | MM-JACKSON3 |
| Author | business-analyst |
| Status | draft |
| Created | 2026-06-06 |

## Problem statement

Muscle Mentor must standardize on **Jackson 3** as the sole JSON library for application serialization, deserialization, and JSON manipulation. Mixed Jackson 2 (`com.fasterxml.jackson`) and Jackson 3 (`tools.jackson`) usage creates maintenance risk, inconsistent APIs, and violates the platform technical direction documented in README.

Today the codebase is **partially migrated**: most services and tests use `tools.jackson`, but some production classes still import `com.fasterxml.jackson` packages.

## Target users

- **Development team** — must write and maintain code against one JSON stack
- **Architects / tech leads** — need a clear, enforceable standard
- **QA** — must verify no Jackson 2 or alternate JSON libraries remain in application code paths

## User stories

### US-1: Single JSON library standard

As a **developer**, I want Muscle Mentor to use **only Jackson 3**, so that JSON handling is consistent across REST APIs, persistence layers, outbox events, and tests.

**Acceptance criteria:**

- [ ] Given the production codebase, when scanning `src/main/java`, then no imports from `com.fasterxml.jackson.*` exist
- [ ] Given the test codebase, when scanning `src/test/java`, then no imports from `com.fasterxml.jackson.*` exist
- [ ] Given any JSON serialization/deserialization in application code, when implemented, then it uses `tools.jackson` packages (e.g. `tools.jackson.databind.json.JsonMapper`, `tools.jackson.databind.ObjectMapper`)
- [ ] Given `pom.xml` dependencies, when reviewed, then no direct dependency on Jackson 2 artifacts (`com.fasterxml.jackson.core`, `com.fasterxml.jackson.databind`, etc.) is declared
- [ ] Given README and internal docs, when updated, then they state Jackson 3 (`tools.jackson`) as the mandatory JSON library

### US-2: Migrate remaining Jackson 2 usages

As a **developer**, I want existing Jackson 2 imports replaced with Jackson 3 equivalents, so that the codebase complies with the new standard without behavior regressions.

**Acceptance criteria:**

- [ ] Given `ApiResponse` and `ApiErrorResponse`, when migrated, then annotations use Jackson 3 packages (e.g. `tools.jackson.annotation.JsonInclude`)
- [ ] Given `OutboxEventPublisher`, when migrated, then it uses `tools.jackson` for `JsonMapper` and exception types (no `com.fasterxml.jackson.core.JsonProcessingException`)
- [ ] Given all intake services/repositories using `ObjectMapper`, when reviewed, then they inject Spring-managed Jackson 3 `JsonMapper`/`ObjectMapper` consistently (prefer `JsonMapper` per README convention where applicable)
- [ ] Given the full test suite, when executed, then all tests pass with no JSON-related failures

### US-3: Prevent regression

As a **tech lead**, I want guardrails so Jackson 2 cannot be reintroduced, so that the standard remains enforced over time.

**Acceptance criteria:**

- [ ] Given CI or local build, when a new `com.fasterxml.jackson` import is added under `src/`, then the build or ArchUnit test fails with a clear message
- [ ] Given code review guidelines (or agent rules), when documented, then reviewers reject PRs introducing Jackson 2 or non-Jackson JSON libraries in application code

## Current state (baseline)

| Area | Status |
|------|--------|
| Spring Boot starter | `spring-boot-starter-jackson` (Boot 4 → Jackson 3) |
| Most main/test code | `tools.jackson.databind.*` |
| Known Jackson 2 imports | `ApiResponse`, `ApiErrorResponse`, `OutboxEventPublisher` |
| README | Already documents Jackson 3 / JsonMapper |

## Out of scope

- Replacing **jjwt-gson** (Gson used internally by JJWT library) — third-party runtime dependency, not application JSON handling; document as accepted exception unless security/architecture decides otherwise
- Changing REST API response shapes or field naming
- Migrating non-JSON serialization (JWT, XML, etc.)
- Upgrading Spring Boot or Jackson versions beyond what Boot 4.0.6 manages

## Success metrics

- **0** `com.fasterxml.jackson` imports in `src/main/java` and `src/test/java`
- **100%** test suite green after migration
- ArchUnit or equivalent rule in place blocking Jackson 2 imports
- README / AGENTS developer skill aligned with Jackson 3-only rule

## Open questions

- [ ] Should `ObjectMapper` be standardized to `JsonMapper` everywhere, or is `tools.jackson.databind.ObjectMapper` acceptable where already used?
- [ ] Should jjwt-gson remain, or switch to a Jackson-based JJWT module if one is compatible with Jackson 3?

## Handoff

```
status: done
artifact_paths: [agents/artifacts/jackson3-only/prd.md]
next_agent: architect
```
