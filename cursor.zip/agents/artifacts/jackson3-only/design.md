# Design: Jackson 3 Only Standard

| Field | Value |
|-------|-------|
| Feature ID | MM-JACKSON3 |
| Author | architect |
| Status | approved |
| PRD | agents/artifacts/jackson3-only/prd.md |
| Created | 2026-06-06 |

## Overview

Complete the Jackson 3 migration by replacing the three remaining Jackson 2 (`com.fasterxml.jackson`) import sites, standardizing on Spring-managed `JsonMapper` for production JSON work, and adding an ArchUnit guard to prevent regression. No API contract or payload shape changes.

Spring Boot 4.0.6 with `spring-boot-starter-jackson` already ships Jackson 3 under `tools.jackson.*`. This design aligns all application code with that stack.

## PRD open questions — decisions

| Question | Decision |
|----------|----------|
| `ObjectMapper` vs `JsonMapper` | **Standardize on `JsonMapper`** in production code and tests. |
| `jjwt-gson` | **Keep** as documented exception. |

## Components

| Component | Responsibility |
|-----------|----------------|
| DTO layer (`common.dto`) | Jackson 3 annotations on API response wrappers |
| Outbox (`infrastructure.outbox`) | Serialize outbox payloads with injected `JsonMapper` |
| Intake modules (`training`, `diet`) | JSON column read/write via injected `JsonMapper` |
| ArchUnit (`arch`) | Fail build if legacy Jackson databind/core is referenced |
| Developer skill / README | Document mandatory Jackson 3 standard |

## Migration plan

See implemented phases: Jackson 2 import fixes, `JsonMapper` injection, test alignment, ArchUnit rules, documentation.

## Handoff

```
status: done
artifact_paths: [agents/artifacts/jackson3-only/design.md]
next_agent: developer
```
