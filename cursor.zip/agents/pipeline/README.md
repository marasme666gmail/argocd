# Agent pipeline orchestrator

Runs the Muscle Mentor multi-agent workflow (BA → Architect → Developer → Code Review → Security → Tester) using the [Cursor SDK](https://cursor.com/docs/sdk/typescript), without manual chat handoffs.

## Prerequisites

**Option A — Node.js locally**

- Node.js 22+
- Java 26 + Maven (for verification step)
- `CURSOR_API_KEY` from [Cursor Dashboard → Integrations](https://cursor.com/dashboard/integrations)

**Option B — Docker (no local Node)**

- Docker Desktop
- `CURSOR_API_KEY` (same as above)
- Docker image includes **Java 26 + Maven**. Pipeline always runs Maven verify at the end (`SKIP_MVN=false`).

## Bash script (recommended)

From `agents/pipeline`:

1. Edit the **CONFIG** block at the top of `run-pipeline.sh` (API key, feature name, description, slug).
2. Run:

```bash
chmod +x run-pipeline.sh

./run-pipeline.sh --dry-run
./run-pipeline.sh                    # rebuilds image, then runs pipeline
```

## Docker run (no Node on host)

From repo root (`muscle-mentor-core`):

```bash
docker pull node:24-slim   # optional; Dockerfile uses this base

cd agents/pipeline
docker compose build
```

**Git Bash on Windows:** use `docker compose` (or `docker-compose`). You must **rebuild** before the first run:

```bash
docker compose build --no-cache
```

If you see `exec /usr/local/bin/docker-entrypoint.sh: no such file or directory`, the image is stale or was built with Windows CRLF line endings — run `docker compose build --no-cache` again.

**Dry run:**

```bash
cd agents/pipeline
set FEATURE_NAME=User onboarding email
set FEATURE_DESC=Send welcome email after registration.
docker compose run --rm agent-pipeline-dry
```

**Real run (PowerShell):**

```powershell
cd agents\pipeline
$env:CURSOR_API_KEY = "cursor_your_key"
$env:FEATURE_NAME = "User onboarding email"
$env:FEATURE_DESC = "Send welcome email after registration."
$env:FEATURE_SLUG = "user-onboarding-email"
docker compose run --rm agent-pipeline
```

**One-off without compose:**

```powershell
cd C:\muscle-mentor-core\MM-44-agent-testing\muscle-mentor-core\agents\pipeline
docker build -t muscle-mentor-agent-pipeline .
docker run --rm `
  -v "${PWD}\..\..:/workspace" `
  -e CURSOR_API_KEY="cursor_your_key" `
  -e FEATURE_NAME="User onboarding email" `
  -e FEATURE_DESC="Send welcome email after registration." `
  -e SKIP_MVN=false `
  muscle-mentor-agent-pipeline pipeline
```

Dry run: replace last arg with `pipeline:dry` and omit `CURSOR_API_KEY`.

## Local run (Node installed)

```bash
cd agents/pipeline
npm ci

export CURSOR_API_KEY="cursor_..."
export FEATURE_NAME="User onboarding email"
export FEATURE_DESC="Send welcome email after registration with verification link."

npm run pipeline
```

Dry run (prints prompts, no API calls):

```bash
npm run pipeline:dry
```

Optional env:

| Variable | Default | Description |
|----------|---------|-------------|
| `FEATURE_SLUG` | slugified `FEATURE_NAME` | Artifact folder under `agents/artifacts/` |
| `MAX_FIX_LOOPS` | `2` | Developer re-run loops after security/tester |
| `SKIP_MVN` | `false` | Set `true` only to skip Maven verify (not recommended) |
| `PIPELINE_MODEL` | `composer-2.5` | Cursor model id |

## Output

- Artifacts: `agents/artifacts/<feature-slug>/`
- State file: `agents/artifacts/<feature-slug>/pipeline-state.json`

## GitHub Actions

Workflow: `.github/workflows/agent-pipeline.yml`

**Manual:** Actions → Agent Feature Pipeline → Run workflow

**From issue:** Add label `agent-pipeline` to an issue (title = feature name, body = requirement)

**Secret required:** `CURSOR_API_KEY` in repository secrets.

On success, the workflow commits changes and opens a PR.
