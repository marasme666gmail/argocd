#!/usr/bin/env node
/**
 * Orchestrates the Muscle Mentor multi-agent pipeline via Cursor SDK.
 *
 * Env:
 *   CURSOR_API_KEY   — required (unless --dry-run)
 *   FEATURE_NAME     — slug source / display name (required)
 *   FEATURE_DESC     — business requirement text (required)
 *   FEATURE_SLUG     — optional override for agents/artifacts/<slug>/
 *   MAX_FIX_LOOPS    — max developer revision loops (default 2)
 *   SKIP_MVN         — set "true" to skip Maven verification (default: run verify)
 *   PIPELINE_MODEL   — Cursor model id (default composer-2.5)
 */

import { spawnSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { Agent, CursorAgentError } from "@cursor/sdk";
import {
  type AgentRole,
  type PipelineState,
  type StageRecord,
  loadState,
  parseHandoff,
  saveState,
  slugifyFeatureName,
} from "./lib/pipeline-state.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = resolve(__dirname, "../..");
const TEMPLATE_DIR = join(REPO_ROOT, "agents/artifacts/_template");

const dryRun = process.argv.includes("--dry-run");

function requireEnv(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) {
    console.error(`Missing required env: ${name}`);
    process.exit(1);
  }
  return value;
}

function initArtifactDir(slug: string): string {
  const artifactDir = join(REPO_ROOT, "agents/artifacts", slug);
  mkdirSync(artifactDir, { recursive: true });
  if (existsSync(TEMPLATE_DIR)) {
    for (const file of readdirSync(TEMPLATE_DIR)) {
      if (!file.endsWith(".md")) continue;
      const dest = join(artifactDir, file);
      if (!existsSync(dest)) {
        copyFileSync(join(TEMPLATE_DIR, file), dest);
      }
    }
  }
  return artifactDir;
}

function relArtifactPath(artifactDir: string): string {
  return artifactDir.replace(REPO_ROOT + "/", "").replace(/\\/g, "/");
}

function stagePrompt(
  agent: AgentRole,
  artifactDir: string,
  featureDesc: string,
  extra = "",
): string {
  const rel = relArtifactPath(artifactDir);
  const base = (() => {
    switch (agent) {
      case "business-analyst":
        return [
          "Use the business-analyst skill.",
          `Feature: ${featureDesc}`,
          `Create ${rel}/prd.md`,
        ];
      case "architect":
        return [
          "Use the architect skill.",
          `Read ${rel}/prd.md`,
          `Create ${rel}/design.md`,
        ];
      case "developer":
        return [
          "Use the developer skill.",
          `Read ${rel}/prd.md and ${rel}/design.md`,
          `If ${rel}/code-review.md, ${rel}/security-review.md, or ${rel}/defects.md list open Must-fix/Critical/High items, fix those first.`,
          "Implement in src/",
        ];
      case "code-reviewer":
        return [
          "Use the code-reviewer skill.",
          `Read ${rel}/prd.md, ${rel}/design.md, and src/ changes for this feature.`,
          `Create ${rel}/code-review.md`,
        ];
      case "security-reviewer":
        return [
          "Use the security-reviewer skill.",
          `Read ${rel}/prd.md, ${rel}/design.md, and src/ changes for this feature.`,
          `Create ${rel}/security-review.md`,
        ];
      case "tester":
        return [
          "Use the tester skill.",
          `Read ${rel}/prd.md, ${rel}/design.md, ${rel}/code-review.md, ${rel}/security-review.md, and src/ changes.`,
          `Create ${rel}/test-plan.md and ${rel}/defects.md; add tests as needed.`,
        ];
    }
  })();
  return [...base, extra, "End with handoff: status, artifact_paths, next_agent."]
    .filter(Boolean)
    .join("\n");
}

async function runAgent(
  agent: AgentRole,
  prompt: string,
  apiKey: string,
  model: string,
): Promise<{ ok: boolean; output: string; error?: string }> {
  console.log(`\n=== Running agent: ${agent} ===\n`);
  if (dryRun) {
    console.log("[dry-run] prompt:\n", prompt);
    return { ok: true, output: "status: done\nnext_agent: none" };
  }

  try {
    const result = await Agent.prompt(prompt, {
      apiKey,
      model: { id: model },
      local: { cwd: REPO_ROOT },
    });

    const output = result.result ?? "";
    if (result.status === "error") {
      return { ok: false, output, error: "Agent run ended with status=error" };
    }
    return { ok: true, output };
  } catch (err) {
    if (err instanceof CursorAgentError) {
      return { ok: false, output: "", error: `CursorAgentError: ${err.message}` };
    }
    throw err;
  }
}

function runMavenVerify(): boolean {
  if (process.env.SKIP_MVN === "true") {
    console.log("Skipping Maven verify (SKIP_MVN=true)");
    return true;
  }
  console.log("\n=== Maven verify (ArchUnit + compile) ===\n");
  const mvn = process.platform === "win32" ? "mvn.cmd" : "mvn";
  const result = spawnSync(
    mvn,
    [
      "-q",
      "test",
      "-Dtest=Jackson3RulesTest,ArchitectureRulesTest,Jackson3SerializationTest",
    ],
    { cwd: REPO_ROOT, stdio: "inherit", shell: process.platform === "win32" },
  );
  return result.status === 0;
}

function ensureStage(state: PipelineState, agent: AgentRole): void {
  if (!state.stages.some((s) => s.agent === agent)) {
    state.stages.push({ agent, status: "pending" });
  }
}

function updateStage(state: PipelineState, agent: AgentRole, patch: Partial<StageRecord>): void {
  ensureStage(state, agent);
  const idx = state.stages.findIndex((s) => s.agent === agent);
  state.stages[idx] = { ...state.stages[idx], ...patch };
}

async function runStage(
  state: PipelineState,
  artifactDir: string,
  featureDesc: string,
  agent: AgentRole,
  apiKey: string,
  model: string,
  extra = "",
): Promise<{ ok: boolean; handoff: ReturnType<typeof parseHandoff> }> {
  updateStage(state, agent, { status: "running", startedAt: new Date().toISOString() });
  state.currentAgent = agent;
  saveState(artifactDir, state);

  const { ok, output, error } = await runAgent(
    agent,
    stagePrompt(agent, artifactDir, featureDesc, extra),
    apiKey,
    model,
  );

  if (!ok) {
    updateStage(state, agent, {
      status: "failed",
      finishedAt: new Date().toISOString(),
      error,
    });
    saveState(artifactDir, state);
    return { ok: false, handoff: {} };
  }

  const handoff = parseHandoff(output);
  updateStage(state, agent, {
    status: handoff.status === "blocked" ? "blocked" : "done",
    finishedAt: new Date().toISOString(),
  });
  saveState(artifactDir, state);
  return { ok: true, handoff };
}

async function main(): Promise<void> {
  const featureName = requireEnv("FEATURE_NAME");
  const featureDesc = requireEnv("FEATURE_DESC");
  const slug = process.env.FEATURE_SLUG?.trim() || slugifyFeatureName(featureName);
  const maxFixLoops = Number(process.env.MAX_FIX_LOOPS ?? "2");
  const model = process.env.PIPELINE_MODEL?.trim() || "composer-2.5";
  const apiKey = process.env.CURSOR_API_KEY?.trim();

  if (!dryRun && !apiKey) {
    console.error("Missing CURSOR_API_KEY (or pass --dry-run)");
    process.exit(1);
  }

  const artifactDir = initArtifactDir(slug);
  console.log(`Feature slug: ${slug}`);
  console.log(`Artifacts: ${artifactDir}`);

  const state: PipelineState = loadState(artifactDir) ?? {
    featureSlug: slug,
    featureDescription: featureDesc,
    artifactDir,
    currentAgent: "business-analyst",
    stages: [],
    updatedAt: new Date().toISOString(),
  };

  const key = apiKey ?? "dry-run";

  for (const agent of ["business-analyst", "architect", "developer"] as const) {
    const result = await runStage(state, artifactDir, featureDesc, agent, key, model);
    if (!result.ok) {
      console.error(`Pipeline failed at ${agent}`);
      process.exit(2);
    }
    if (result.handoff.status === "blocked") {
      console.error(`Agent ${agent} reported blocked`);
      process.exit(3);
    }
  }

  for (let i = 0; i <= maxFixLoops; i++) {
    const cr = await runStage(
      state,
      artifactDir,
      featureDesc,
      "code-reviewer",
      key,
      model,
      i > 0 ? "Re-review after developer fixes." : "",
    );
    if (!cr.ok) {
      process.exit(2);
    }
    if (cr.handoff.status === "done" && cr.handoff.nextAgent !== "developer") {
      break;
    }
    if (i === maxFixLoops) {
      console.error("Code review still requires developer fixes after max loops");
      process.exit(3);
    }
    const devCr = await runStage(state, artifactDir, featureDesc, "developer", key, model);
    if (!devCr.ok) {
      process.exit(2);
    }
  }

  for (let i = 0; i <= maxFixLoops; i++) {
    const sec = await runStage(
      state,
      artifactDir,
      featureDesc,
      "security-reviewer",
      key,
      model,
      i > 0 ? "Re-review after developer fixes." : "",
    );
    if (!sec.ok) {
      process.exit(2);
    }
    if (sec.handoff.status === "done" && sec.handoff.nextAgent !== "developer") {
      break;
    }
    if (i === maxFixLoops) {
      console.error("Security review still requires developer fixes after max loops");
      process.exit(3);
    }
    const devSec = await runStage(state, artifactDir, featureDesc, "developer", key, model);
    if (!devSec.ok) {
      process.exit(2);
    }
  }

  for (let i = 0; i <= maxFixLoops; i++) {
    const qa = await runStage(state, artifactDir, featureDesc, "tester", key, model);
    if (!qa.ok) {
      process.exit(2);
    }
    if (qa.handoff.status === "done" && qa.handoff.nextAgent === "none") {
      break;
    }
    if (i === maxFixLoops) {
      console.error("Tester still reports defects after max loops");
      process.exit(3);
    }
    const dev = await runStage(state, artifactDir, featureDesc, "developer", key, model);
    if (!dev.ok) {
      process.exit(2);
    }
  }

  if (!runMavenVerify()) {
    console.error("Maven verification failed");
    process.exit(4);
  }

  state.currentAgent = "none";
  saveState(artifactDir, state);
  console.log("\nPipeline complete.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
