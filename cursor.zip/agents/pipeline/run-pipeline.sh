#!/usr/bin/env bash
# Run the Muscle Mentor multi-agent pipeline via Docker Compose.
#
# 1. Edit the CONFIG section below before each run
# 2. chmod +x run-pipeline.sh
# 3. ./run-pipeline.sh          or   ./run-pipeline.sh --dry-run

set -euo pipefail

# ============ CONFIG — edit before each run ============
export CURSOR_API_KEY="crsr_b5985be7aef6746a401f5d49b782a2aebd8e6a21d2a73fb869858d88d59cce89"
export FEATURE_NAME="Password reset"
export FEATURE_DESC="Users can reset password via email link."
export FEATURE_SLUG="password-reset"

# Optional (uncomment to override defaults)
# export MAX_FIX_LOOPS="2"
# export PIPELINE_MODEL="composer-2.5"
# =======================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

DRY_RUN=false

usage() {
  cat <<'EOF'
Run the Muscle Mentor agent pipeline via Docker (BA → Architect → Developer → Code Review → Security → Tester).

Edit the CONFIG section at the top of run-pipeline.sh before each run.
The Docker image is rebuilt automatically before each run.
Maven verification runs at the end of every pipeline (ArchUnit + Jackson rules).

Usage:
  ./run-pipeline.sh [options]

Options:
  --dry-run     Print prompts only; no Cursor API calls
  -h, --help    Show this help

Requires: Docker Desktop / docker compose

Output:
  agents/artifacts/<FEATURE_SLUG>/
  agents/artifacts/<FEATURE_SLUG>/pipeline-state.json
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) DRY_RUN=true ;;
    --build)
      echo "Note: Image is always built before run; --build is not required." >&2
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    --docker | --local)
      echo "Note: Pipeline always runs via Docker; ignoring $1" >&2
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift
done

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: docker not found. Install Docker Desktop." >&2
  exit 1
fi

export MAX_FIX_LOOPS="${MAX_FIX_LOOPS:-2}"
export PIPELINE_MODEL="${PIPELINE_MODEL:-composer-2.5}"
export SKIP_MVN="false"

if [[ "$DRY_RUN" == false ]]; then
  if [[ -z "${FEATURE_NAME}" ]]; then
    echo "ERROR: FEATURE_NAME is empty. Edit CONFIG in run-pipeline.sh." >&2
    exit 1
  fi
  if [[ -z "${FEATURE_DESC}" ]]; then
    echo "ERROR: FEATURE_DESC is empty. Edit CONFIG in run-pipeline.sh." >&2
    exit 1
  fi
  if [[ -z "${CURSOR_API_KEY}" || "${CURSOR_API_KEY}" == "cursor_your_key_here" ]]; then
    echo "ERROR: Set CURSOR_API_KEY in the CONFIG section of run-pipeline.sh." >&2
    echo "Get a key from https://cursor.com/dashboard/integrations" >&2
    exit 1
  fi
fi

echo "Dry run:   $DRY_RUN"
echo "Feature:   ${FEATURE_NAME}"
echo "Slug:      ${FEATURE_SLUG}"
echo ""

echo "Building Docker image..."
docker compose build

if [[ "$DRY_RUN" == true ]]; then
  docker compose run --rm agent-pipeline-dry
else
  docker compose run --rm agent-pipeline
fi
