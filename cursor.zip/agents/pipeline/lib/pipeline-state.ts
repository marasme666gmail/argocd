import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";

export type AgentRole =
  | "business-analyst"
  | "architect"
  | "developer"
  | "code-reviewer"
  | "security-reviewer"
  | "tester";

export type PipelineStatus = "pending" | "running" | "done" | "blocked" | "needs_revision" | "failed";

export interface StageRecord {
  agent: AgentRole;
  status: PipelineStatus;
  startedAt?: string;
  finishedAt?: string;
  error?: string;
}

export interface PipelineState {
  featureSlug: string;
  featureDescription: string;
  artifactDir: string;
  currentAgent: AgentRole | "none";
  stages: StageRecord[];
  updatedAt: string;
}

const HANDOFF_STATUS = /status:\s*(done|blocked|needs_revision)/i;
const HANDOFF_NEXT = /next_agent:\s*([a-z-]+|none)/i;

export function parseHandoff(text: string): {
  status?: "done" | "blocked" | "needs_revision";
  nextAgent?: string;
} {
  const statusMatch = text.match(HANDOFF_STATUS);
  const nextMatch = text.match(HANDOFF_NEXT);
  const status = statusMatch?.[1]?.toLowerCase() as
    | "done"
    | "blocked"
    | "needs_revision"
    | undefined;
  const nextAgent = nextMatch?.[1]?.toLowerCase();
  return { status, nextAgent };
}

export function loadState(artifactDir: string): PipelineState | null {
  const path = join(artifactDir, "pipeline-state.json");
  if (!existsSync(path)) return null;
  return JSON.parse(readFileSync(path, "utf8")) as PipelineState;
}

export function saveState(artifactDir: string, state: PipelineState): void {
  state.updatedAt = new Date().toISOString();
  writeFileSync(join(artifactDir, "pipeline-state.json"), JSON.stringify(state, null, 2));
}

export function slugifyFeatureName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
}
