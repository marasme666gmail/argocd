#!/bin/sh
set -e
cd /workspace/agents/pipeline
# node_modules lives on a Docker volume (see docker-compose.yml), not the host mount
if [ ! -d node_modules/@cursor/sdk ]; then
  npm install --silent
fi
exec npm run "$@"
