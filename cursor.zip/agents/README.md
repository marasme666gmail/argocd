# Agent Team — Muscle Mentor

This project uses six independent Cursor agents that hand off work through artifacts in `agents/artifacts/<feature>/`.

Agent skills and workflow rules live in `.cursor/` (required by Cursor). Feature outputs and the automated pipeline live under `agents/`.

## Layout

```
agents/
├── README.md           # this file
├── artifacts/          # PRDs, designs, reviews, test plans per feature
│   ├── _template/
│   └── <feature-slug>/
└── pipeline/           # Cursor SDK orchestrator
```

## Roles

| Agent | Skill | Produces |
|-------|-------|----------|
| Business Analyst | `business-analyst` | `prd.md` |
| Architect | `architect` | `design.md` |
| Developer | `developer` | code in `src/` |
| Code Reviewer | `code-reviewer` | `code-review.md` |
| Security Reviewer | `security-reviewer` | `security-review.md` |
| Tester | `tester` | `test-plan.md`, `defects.md`, tests |

## Standard flow

```
PRD → Design → Build → Code Review → Security Review → Test → (fix loops if needed)
```

## Quick start

### 1. Create a feature folder

```bash
mkdir agents/artifacts/my-feature
cp agents/artifacts/_template/*.md agents/artifacts/my-feature/
```

### 2. Run each agent in Cursor chat

**Business Analyst**

```
Use the business-analyst skill.
Feature: [describe the feature]
Create agents/artifacts/my-feature/prd.md
```

**Architect**

```
Use the architect skill.
Read agents/artifacts/my-feature/prd.md
Create agents/artifacts/my-feature/design.md
```

**Developer**

```
Use the developer skill.
Read agents/artifacts/my-feature/prd.md and design.md
Implement in src/
```

**Code Reviewer**

```
Use the code-reviewer skill.
Read agents/artifacts/my-feature/prd.md, design.md, and src changes.
Create agents/artifacts/my-feature/code-review.md
```

**Security Reviewer**

```
Use the security-reviewer skill.
Read agents/artifacts/my-feature/prd.md, design.md, and src changes.
Create agents/artifacts/my-feature/security-review.md
```

**Tester**

```
Use the tester skill.
Read agents/artifacts/my-feature/prd.md, design.md, code-review.md, security-review.md, and src changes.
Create test-plan.md and defects.md; add tests.
```

### 3. Loop back when needed

- Code review findings in `code-review.md` → run **developer**, then **code-reviewer** again
- Security findings in `security-review.md` → run **developer**, then **security-reviewer** again
- Defects in `defects.md` → run **developer** again
- Design gap → run **architect**
- Unclear requirement → run **business-analyst**

## Artifact ownership

| File | Owner | Readers |
|------|-------|---------|
| `prd.md` | business-analyst | architect, developer, code-reviewer, security-reviewer, tester |
| `design.md` | architect | developer, code-reviewer, security-reviewer, tester |
| `code-review.md` | code-reviewer | developer, security-reviewer, tester |
| `security-review.md` | security-reviewer | developer, tester |
| `test-plan.md` | tester | all |
| `defects.md` | tester | developer |

## Configuration

- Workflow rules: `.cursor/rules/multi-agent-workflow.mdc`
- Agent skills: `.cursor/skills/<role>/SKILL.md`
- Templates: `agents/artifacts/_template/`

## Automated pipeline (no manual chat)

Orchestrator: `agents/pipeline/run-feature-pipeline.ts` (Cursor SDK)

**Bash script:**

```bash
cd agents/pipeline
chmod +x run-pipeline.sh
# Edit CONFIG at top of run-pipeline.sh, then:
./run-pipeline.sh --dry-run
./run-pipeline.sh
```

**Docker (no Node on host):**

```bash
cd agents/pipeline
docker compose build
export CURSOR_API_KEY="cursor_..."
export FEATURE_NAME="My feature"
export FEATURE_DESC="Business requirement."
docker compose run --rm agent-pipeline
```

**Local (Node installed):**

```bash
cd agents/pipeline && npm ci
export CURSOR_API_KEY="cursor_..."
export FEATURE_NAME="My feature"
export FEATURE_DESC="Business requirement text."
npm run pipeline
```

**GitHub Actions:** `.github/workflows/agent-pipeline.yml`

- Manual: workflow_dispatch with feature name + description
- Issue trigger: add label `agent-pipeline` (requires `CURSOR_API_KEY` repo secret)

See `agents/pipeline/README.md` for full options.
